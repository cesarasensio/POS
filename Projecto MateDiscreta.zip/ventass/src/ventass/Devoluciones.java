package ventass;

import java.sql.*;
import javax.swing.*;
import java.text.DateFormat;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.swing.table.*;

public class Devoluciones extends javax.swing.JFrame {
Statement st;
Date date = new Date();
int cantida,opcion;
float precioC,precioV;
String product,code;  
DateFormat format = new SimpleDateFormat("yyyy-MM-dd ");
DefaultTableModel modelo=new DefaultTableModel();    
Object [] fila=new Object[10];
public Devoluciones() {
        initComponents();
        
            try
{
Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/Trabajo", "root","");
            st=conn.createStatement();

}
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
        }
                     jLabel5.setText(format.format(date));
               modelo.addColumn("Codigo");
               modelo.addColumn("Producto");
               modelo.addColumn("Devolucion");
               modelo.addColumn("Existencia de Producto");
               modelo.addColumn("Fecha de Devolucion");
               modelo.addColumn("Precio Costo");
               modelo.addColumn("Total Costo de Devolucion");
               modelo.addColumn("Precio Venta");
               modelo.addColumn("Total Venta de Devolucion");
               modelo.addColumn("Causa de Devolucion");
             
               devolucion.setEnabled(false);
               productos.setEditable(false);
               cantidad.setEditable(false);
               venta.setEnabled(false);
               compra.setEnabled(false);
    }

    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        codigo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        productos = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cantidad = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        causas = new javax.swing.JComboBox();
        jLabel9 = new javax.swing.JLabel();
        Tab = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        venta = new javax.swing.JRadioButton();
        compra = new javax.swing.JRadioButton();
        devolucion = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        inventario = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Producto a Devolver"));

        jLabel2.setText("Codigo");

        codigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                codigoKeyPressed(evt);
            }
        });

        jLabel3.setText("Producto");

        productos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                productosKeyPressed(evt);
            }
        });

        jLabel4.setText("Fecha");

        jLabel5.setText("jLabel5");

        jLabel6.setText("Cantidad");

        jLabel7.setText("Causas por Devolucion");

        causas.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Defecto de fabrica", "No supera expectativas", "mal manejo" }));

        jLabel9.setText("Clasificacion del producto");

        Tab.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "calzado", "bolsas", "juguetes", "ropa", "accesorios" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cantidad)
                    .addComponent(codigo, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(productos, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Tab, 0, 96, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(causas, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(productos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel9)
                    .addComponent(Tab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(causas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addContainerGap(62, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Virtual DJ", 3, 14));
        jLabel1.setText("Devoluciones de Producto");

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Devoluciones"));

        buttonGroup1.add(venta);
        venta.setText("Ventas");
        venta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ventaMouseClicked(evt);
            }
        });

        buttonGroup1.add(compra);
        compra.setText("Compras");
        compra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compraMouseClicked(evt);
            }
        });

        devolucion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/qual-icon.png"))); // NOI18N
        devolucion.setText("Devolucion");
        devolucion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                devolucionMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(venta)
                    .addComponent(compra)
                    .addComponent(devolucion))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(venta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(compra)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(devolucion)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Inventario de Devolucion"));

        inventario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Codigo", "Producto", "Devolucion", "Existencia", "Fecha", "Precio Costo", "Total Precio Costo Devolucion", "Precio Venta", "Total Precio Venta Devolucion", "Causa de Devolucion"
            }
        ));
        inventario.setEnabled(false);
        jScrollPane1.setViewportView(inventario);

        jLabel8.setText("Cambiar Productos Ventas");

        jButton2.setText("Cambiar Producto");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 733, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(68, 68, 68)
                        .addComponent(jButton2)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jButton2))
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(137, 137, 137)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(56, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void codigoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codigoKeyPressed
String variable=(String)Tab.getSelectedItem();
        if(evt.getKeyCode()==evt.VK_ENTER)
{
    
    
 try
                {
                    ResultSet rt=st.executeQuery("SELECT * FROM producto WHERE codigo='"+codigo.getText()+"'&& categoria='"+variable+"'");

                    while(rt.next())
                    {
                  code=rt.getString("codigo");
                  product=rt.getString("producto");
                  precioC=rt.getFloat("precioCosto");
                cantida=rt.getInt("cantidad"); 
                  precioV=rt.getFloat("precioVenta");
                 productos.setText(product);
                          
               devolucion.setEnabled(true);
               cantidad.setEditable(true);
               venta.setEnabled(true);
               compra.setEnabled(true);
               
               cantidad.requestFocus();
                }
                }
                     catch(Exception e)
            {
            JOptionPane.showMessageDialog(null,"Error de conexion" );    
            }
}
    }//GEN-LAST:event_codigoKeyPressed

    private void devolucionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_devolucionMouseClicked
switch(opcion)
{
    case 1:
        String devolu=cantidad.getText();
int dev=Integer.parseInt(devolu);
int Resta=cantida-dev;
float suma=precioC*dev;
float sum=precioV*dev;
String causa=(String)causas.getSelectedItem(); 
        
 String fecha=jLabel5.getText(); 
 
                 fila[0]=code;
                 fila[1]=product;
                 fila[2]=dev;
                 fila[3]=Resta;
                 fila[4]=fecha;
                 fila[5]=precioC;
                 fila[6]=suma;
                 fila[7]=precioV;
                 fila[8]=sum;
                 fila[9]=causa;

       modelo.addRow(fila);
         inventario.setModel(modelo);

String variable=(String)Tab.getSelectedItem();
    try
            {
                st.executeUpdate("INSERT INTO movimientos VALUES(id,'"+codigo.getText()+"','"+productos.getText()+"','"+dev+"','"+Resta+"','"+fecha+"','"+precioC+"','"+suma+"','"+precioV+"','"+sum+"','"+causa+"','Devolucion por Compra','Vacio')");
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
            }
  try
            {
               
              st.executeUpdate("UPDATE "+variable+" SET cantidad='"+Resta+"' WHERE codigo='"+codigo.getText()+"' && categoria='"+variable+"'");

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
            }
    
  productos.setText("");
  cantidad.setText("");
  codigo.setText("");   

        break;
    case 2:
        String devol=cantidad.getText();
int devo=Integer.parseInt(devol);
int Suma=cantida+devo;
float sm=precioC*devo;
float su=precioV*devo;
String caus=(String)causas.getSelectedItem(); 
        
 String fech=jLabel5.getText(); 
 if(cantida==0)
 {
 JOptionPane.showMessageDialog(null, "No hay Producto Para devolver");
 }
 else
 {
 if(cantida<=-1)
 {
     JOptionPane.showMessageDialog(null, "No hay Producto Para devolver");
 }
 else
 {
     
                 fila[0]=code;
                 fila[1]=product;
                 fila[2]=devo;
                 fila[3]=Suma;
                 fila[4]=fech;
                 fila[5]=precioC;
                 fila[6]=sm;
                 fila[7]=precioV;
                 fila[8]=su;
                 fila[9]=caus;

       modelo.addRow(fila);
         inventario.setModel(modelo);

String variabl=(String)Tab.getSelectedItem();
    try
            {
                st.executeUpdate("INSERT INTO movimientos VALUES(id,'"+codigo.getText()+"','"+productos.getText()+"','"+devo+"','"+Suma+"','"+fech+"','"+precioC+"','"+sm+"','"+precioV+"','"+su+"','"+caus+"','Devolucion por Ventas','vacio')");
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
            }
  try
            {
               
              st.executeUpdate("UPDATE producto SET cantidad='"+Suma+"' WHERE codigo='"+codigo.getText()+"'&& categoria='"+variabl+"'");

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
            }
 }
 }    
 
    
  productos.setText("");
  cantidad.setText("");
  codigo.setText("");   
        
        break;
}
    }//GEN-LAST:event_devolucionMouseClicked

    private void ventaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ventaMouseClicked
opcion=2;
    }//GEN-LAST:event_ventaMouseClicked

    private void compraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compraMouseClicked
opcion=1;
    }//GEN-LAST:event_compraMouseClicked

    private void productosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_productosKeyPressed

    }//GEN-LAST:event_productosKeyPressed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Devoluciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Devoluciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Devoluciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Devoluciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new Devoluciones().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox Tab;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField cantidad;
    private javax.swing.JComboBox causas;
    private javax.swing.JTextField codigo;
    private javax.swing.JRadioButton compra;
    private javax.swing.JButton devolucion;
    private javax.swing.JTable inventario;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField productos;
    private javax.swing.JRadioButton venta;
    // End of variables declaration//GEN-END:variables
}
