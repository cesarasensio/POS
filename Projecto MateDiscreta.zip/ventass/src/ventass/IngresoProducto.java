package ventass;


import java.sql.*;
import javax.swing.*;
import javax.swing.table.*;

public class IngresoProducto extends javax.swing.JFrame {

    Statement st;
    DefaultTableModel modelo = new DefaultTableModel();    
    Object[] fila = new Object[5];    
    String variable;
    int canti, cantida;    

    public IngresoProducto() {
        initComponents();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Trabajo", "root", "");
            st = conn.createStatement();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
        }        
        
        modelo.addColumn("Codigo");
        modelo.addColumn("Producto");
        modelo.addColumn("Existencia");
        modelo.addColumn("Precio Costo");
        modelo.addColumn("Precio Venta");        
        producto.setEditable(false);
        cantidad.setEditable(false);
        precioCosto.setEditable(false);
        precioVenta.setEditable(false);
        Guardar.setEnabled(false);        
        Eliminar.setEnabled(false);
        Modificar.setEnabled(false);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        producto = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        codigo = new javax.swing.JTextField();
        cantidad = new javax.swing.JTextField();
        precioCosto = new javax.swing.JTextField();
        precioVenta = new javax.swing.JTextField();
        Tab = new javax.swing.JComboBox();
        Guardar = new javax.swing.JButton();
        Modificar = new javax.swing.JButton();
        Eliminar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        Inventario = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Ingreso del Producto"));

        jLabel1.setText("Codigo");

        producto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                productoKeyPressed(evt);
            }
        });

        jLabel2.setText("Producto");

        jLabel3.setText("Clasificacion del producto");

        jLabel4.setText("Cantidad ");

        jLabel5.setText("Precio Costo");

        jLabel6.setText("Precio Venta");

        codigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                codigoKeyPressed(evt);
            }
        });

        cantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cantidadKeyPressed(evt);
            }
        });

        precioCosto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                precioCostoKeyPressed(evt);
            }
        });

        precioVenta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                precioVentaKeyPressed(evt);
            }
        });

        Tab.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "calzado", "bolsas", "juguetes", "ropa", "accesorios" }));
        Tab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabMouseClicked(evt);
            }
        });
        Tab.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                TabKeyPressed(evt);
            }
        });

        Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/yast_bootmode.gif"))); // NOI18N
        Guardar.setText("Guardar");
        Guardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GuardarMouseClicked(evt);
            }
        });

        Modificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/yast_restore.gif"))); // NOI18N
        Modificar.setText("Modificar");
        Modificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ModificarMouseClicked(evt);
            }
        });

        Eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/kcmx.gif"))); // NOI18N
        Eliminar.setText("Eliminar");
        Eliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EliminarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Tab, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addGap(17, 17, 17)
                        .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(precioCosto, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(precioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(Guardar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Modificar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Eliminar))
                    .addComponent(producto, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(Tab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(producto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(precioCosto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(precioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Guardar)
                    .addComponent(Modificar)
                    .addComponent(Eliminar))
                .addContainerGap(50, Short.MAX_VALUE))
        );

        jLabel7.setFont(new java.awt.Font("Virtual DJ", 3, 24));
        jLabel7.setText("INGRESO DEL PRODUCTO");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Inventario Producto"));

        jLabel8.setText("Ver Invertario");

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/kdict.gif"))); // NOI18N
        jButton4.setText("Ver");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });

        Inventario.setAutoCreateRowSorter(true);
        Inventario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Codigo", "Producto", "Existencia", "Precio Costo", "Precio Venta"
            }
        ));
        Inventario.setEnabled(false);
        jScrollPane4.setViewportView(Inventario);

        jLabel9.setText("Limpiar Inventario");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/important.gif"))); // NOI18N
        jButton1.setText("Limpiar");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 774, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jButton4)
                    .addComponent(jLabel9)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(jLabel7))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void GuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GuardarMouseClicked
        String variable = (String) Tab.getSelectedItem();
        try {
            st.executeUpdate("INSERT INTO producto VALUES(id,'" + codigo.getText() + "','" + producto.getText() + "','" + cantidad.getText() + "','" + precioCosto.getText() + "','" + precioVenta.getText() + "','"+variable+"')");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
        }
        producto.setText("");
        cantidad.setText("");
        precioCosto.setText("");
        precioVenta.setText("");   
        Tab.requestFocus();
    }//GEN-LAST:event_GuardarMouseClicked
    
    private void ModificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ModificarMouseClicked
        String variable = (String) Tab.getSelectedItem();
        String exis = cantidad.getText();
        int exist = Integer.parseInt(exis);
        canti = cantida + exist;        
        
        try {
            
            st.executeUpdate("UPDATE producto SET producto='" + producto.getText() + "',cantidad='" + canti + "',precioVenta='" + precioVenta.getText() + "' WHERE codigo='" + codigo.getText()+"' && categoria='"+variable+"'");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
        }
        producto.setText("");
        cantidad.setText("");
        precioCosto.setText("");
        precioVenta.setText("");
        Tab.requestFocus();
    }//GEN-LAST:event_ModificarMouseClicked
    
    private void EliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EliminarMouseClicked
        String variable = (String) Tab.getSelectedItem();
        try {
            
            st.executeUpdate("DELETE  FROM producto WHERE codigo='" + codigo.getText()+"' && categoria='"+variable+"'");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
        }
        
        producto.setText("");
        cantidad.setText("");
        precioCosto.setText("");
        precioVenta.setText("");
        Tab.requestFocus();
    }//GEN-LAST:event_EliminarMouseClicked
    
    private void codigoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codigoKeyPressed
        String variable = (String) Tab.getSelectedItem();
        if (evt.getKeyCode() == evt.VK_ENTER) {
                    Guardar.setEnabled(true);
                    Eliminar.setEnabled(false);
                    Modificar.setEnabled(false);        
                    producto.setEditable(true);
                    cantidad.setEditable(true);
                    precioCosto.setEditable(true);
                    precioVenta.setEditable(true);
                    producto.setText("");
                    cantidad.setText( "");
                    precioCosto.setText( "");
                    precioVenta.setText( "");
                    producto.requestFocus();
            try {
                ResultSet rt = st.executeQuery("SELECT * FROM producto WHERE codigo='" + codigo.getText()+"' && categoria='"+variable+"'");
                
                while (rt.next()) {
                    String product = rt.getString("producto");
                    cantida = rt.getInt("cantidad");
                    float precioC = rt.getFloat("precioCosto");
                    float precioV = rt.getFloat("precioVenta");
                    
                    producto.setText(product);
                    cantidad.setText(cantida + "");
                    precioCosto.setText(precioC + "");
                    precioVenta.setText(precioV + "");
            
                    Guardar.setEnabled(false);
                    Eliminar.setEnabled(true);
                    Modificar.setEnabled(true);        
                    producto.setEditable(true);
                    cantidad.setEditable(true);
                    precioCosto.setEditable(false);
                    precioVenta.setEditable(true);
                    
                    
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error de conexion");                
            }
        }
    }//GEN-LAST:event_codigoKeyPressed
    
    private void TabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabMouseClicked
        
        
    }//GEN-LAST:event_TabMouseClicked
    
    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        
        
        
        String variable = (String) Tab.getSelectedItem();        
        try {
            ResultSet rt = st.executeQuery("SELECT * FROM producto WHERE categoria='"+variable+"'");
            
            while (rt.next()) {
                String code = rt.getString("codigo");
                String product = rt.getString("producto");
                int cantida = rt.getInt("cantidad");
                float precioC = rt.getFloat("precioCosto");
                float precioV = rt.getFloat("precioVenta");
                
                fila[0] = code;
                fila[1] = product;
                fila[2] = cantida;
                fila[3] = precioC;
                fila[4] = precioV;
                
                modelo.addRow(fila);
                Inventario.setModel(modelo);                
                
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de conexion");            
        }        
        
        
    }//GEN-LAST:event_jButton4MouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
       int eliminar=Inventario.getRowCount();
    
       try{
for(int i=0;i<=eliminar;i++){
    
           modelo.removeRow(Inventario.getRowCount()-1);
}
    }
    catch(Exception e)
            {
            JOptionPane.showInternalMessageDialog(null,"" );
           
            }  

       
    }//GEN-LAST:event_jButton1MouseClicked

    private void productoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_productoKeyPressed
if(evt.getKeyCode()==evt.VK_ENTER)
{
cantidad.requestFocus();
}
    }//GEN-LAST:event_productoKeyPressed

    private void cantidadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cantidadKeyPressed
 if(evt.getKeyCode()==evt.VK_ENTER)
{
precioCosto.requestFocus();
}
    }//GEN-LAST:event_cantidadKeyPressed

    private void precioCostoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_precioCostoKeyPressed
  if(evt.getKeyCode()==evt.VK_ENTER)
{
precioVenta.requestFocus();
}
    }//GEN-LAST:event_precioCostoKeyPressed

    private void precioVentaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_precioVentaKeyPressed
   if(evt.getKeyCode()==evt.VK_ENTER)
{
Tab.requestFocus();
}
    }//GEN-LAST:event_precioVentaKeyPressed

    private void TabKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TabKeyPressed
if(evt.getKeyCode()==evt.VK_ENTER)
{
codigo.requestFocus();
}

    }//GEN-LAST:event_TabKeyPressed
        
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IngresoProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IngresoProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IngresoProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IngresoProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            
            public void run() {
                new IngresoProducto().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Eliminar;
    private javax.swing.JButton Guardar;
    private javax.swing.JTable Inventario;
    private javax.swing.JButton Modificar;
    private javax.swing.JComboBox Tab;
    private javax.swing.JTextField cantidad;
    private javax.swing.JTextField codigo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField precioCosto;
    private javax.swing.JTextField precioVenta;
    private javax.swing.JTextField producto;
    // End of variables declaration//GEN-END:variables
}
