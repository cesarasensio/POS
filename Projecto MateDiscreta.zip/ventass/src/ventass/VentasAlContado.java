package ventass;

import java.sql.*;
import javax.swing.*;
import java.text.DateFormat;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.swing.table.*;

public class VentasAlContado extends javax.swing.JFrame {
Statement st;
Date date = new Date();
DateFormat format = new SimpleDateFormat("yyyy-MM-dd ");
DefaultTableModel modelo=new DefaultTableModel();
Object [] fila=new Object[10];

int exis,canti,c;
String producto,codig,code;
float precioC,precioV,suma,multi;

    public VentasAlContado() {
        initComponents();

            try
{
Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/Trabajo", "root","");
            st=conn.createStatement();

}
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
        }
              jLabel11.setText(format.format(date));
               modelo.addColumn("Codigo");
               modelo.addColumn("Producto");
               modelo.addColumn("Cantidad");
               modelo.addColumn("Precio");
               
               cliente.setEditable(false);
               codigo.setEditable(false);
               cantidad.setEditable(false);
               ingresar.setEnabled(false);
               actualizar.setEnabled(false);
               pagar.setEnabled(false);
               nueva.setEnabled(false);
               Nit.setEditable(false);
    }
  
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        Nit = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cliente = new javax.swing.JTextField();
        ingresar = new javax.swing.JButton();
        actualizar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Inventario = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        codigo = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        cantidad = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        Tab = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        descuento = new javax.swing.JComboBox();
        jLabel13 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        Total = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        pagos = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cambio = new javax.swing.JTextField();
        pagar = new javax.swing.JButton();
        nueva = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        Password = new javax.swing.JPasswordField();
        bienvenida = new javax.swing.JLabel();

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Cliente"));

        jLabel2.setText("Nit");

        Nit.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                NitKeyPressed(evt);
            }
        });

        jLabel3.setText("Cliente");

        cliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                clienteKeyPressed(evt);
            }
        });

        ingresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/yast_bootmode.gif"))); // NOI18N
        ingresar.setText("Ingresar");
        ingresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ingresarMouseClicked(evt);
            }
        });

        actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/yast_restore.gif"))); // NOI18N
        actualizar.setText("Actualizar");
        actualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                actualizarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Nit, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cliente, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ingresar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(actualizar)
                .addContainerGap(61, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Nit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(cliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ingresar)
                    .addComponent(actualizar))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Virtual DJ", 3, 24));
        jLabel1.setText("Super Ventas");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Ventas"));

        Inventario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Codigo", "Producto", "Cantidad", "Precio"
            }
        ));
        Inventario.setEnabled(false);
        jScrollPane1.setViewportView(Inventario);

        jLabel7.setText("Codigo");

        codigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                codigoKeyPressed(evt);
            }
        });

        jLabel8.setText("Cantidad");

        cantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cantidadKeyPressed(evt);
            }
        });

        jLabel9.setText("Clasificacion del Producto");

        Tab.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "calzado", "bolsas", "juguetes", "ropa", "accesorios" }));
        Tab.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                TabKeyPressed(evt);
            }
        });

        jLabel10.setText("Fecha");

        jLabel11.setText("jLabel11");

        jLabel12.setText("Descuento");

        descuento.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "5", "10", "12", "15", "20", "25", "30", "35", "40", "45", "50" }));
        descuento.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                descuentoMouseClicked(evt);
            }
        });
        descuento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                descuentoActionPerformed(evt);
            }
        });
        descuento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                descuentoKeyPressed(evt);
            }
        });

        jLabel13.setText("%");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 852, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Tab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(descuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel11)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(Tab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(descuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel13)
                    .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Totales"));

        jLabel4.setText("Total a Pagar");

        Total.setEditable(false);
        Total.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        Total.setText("0");

        jLabel5.setText("Total Pagado");

        pagos.setEditable(false);
        pagos.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        pagos.setText("0");

        jLabel6.setText("Cambio de Pago");

        cambio.setEditable(false);
        cambio.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        cambio.setText("0");

        pagar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/kcalc.gif"))); // NOI18N
        pagar.setText("Pagar");
        pagar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pagarMouseClicked(evt);
            }
        });

        nueva.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/kate.gif"))); // NOI18N
        nueva.setText("Nueva");
        nueva.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nuevaMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pagos, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cambio, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pagar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nueva)
                .addContainerGap(253, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(pagos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(cambio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pagar)
                    .addComponent(nueva))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Usuario"));

        jLabel14.setText("Password");

        Password.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                PasswordKeyPressed(evt);
            }
        });

        bienvenida.setText("Bienvenido a la Venta");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Password, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(bienvenida)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(Password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(bienvenida)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(254, 254, 254)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_NitKeyPressed
if(evt.getKeyCode()==evt.VK_ENTER)
{
               cliente.requestFocus();
               cliente.setEditable(true);
               cliente.setText("");
               ingresar.setEnabled(true);
               codigo.setEditable(false);
               cantidad.setEditable(false);
               actualizar.setEnabled(false);
               
       
try
                {
                    ResultSet rt=st.executeQuery("SELECT * FROM cliente WHERE nit='"+Nit.getText()+"'");

                    while(rt.next())
                    {
String clientes=rt.getString("cliente");                  
         cliente.setText(clientes);
          cliente.setEditable(true);
               
                codigo.setEditable(true);
               cantidad.setEditable(true);
               ingresar.setEnabled(false);
               actualizar.setEnabled(true);
                
                }
                }
                     catch(Exception e)
            {
            JOptionPane.showMessageDialog(null,"Error de conexion" );    
            }
}
    }//GEN-LAST:event_NitKeyPressed

    private void ingresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ingresarMouseClicked
 try
            {
                st.executeUpdate("INSERT INTO cliente VALUES(id,'"+Nit.getText()+"','"+cliente.getText()+"')");
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
            }
    }//GEN-LAST:event_ingresarMouseClicked

    private void actualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_actualizarMouseClicked
try
            {
               
              st.executeUpdate("UPDATE cliente SET cliente='"+cliente.getText()+"' WHERE nit='"+Nit.getText()+"'");

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
            }
    }//GEN-LAST:event_actualizarMouseClicked

    private void cantidadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cantidadKeyPressed
String variable=(String)Tab.getSelectedItem();
String desc=(String)descuento.getSelectedItem();
if (evt.getKeyCode() == evt.VK_ENTER)
{
try
                {
                    ResultSet rt=st.executeQuery("SELECT * FROM producto WHERE codigo='"+codigo.getText()+"'&& categoria='"+variable+"'");

                    while(rt.next())
                    {
                 code=rt.getString("codigo");
                 producto=rt.getString("producto");
                 canti=rt.getInt("cantidad");
                 precioC=rt.getFloat("precioCosto");
                 precioV=rt.getFloat("precioVenta");
    
                 int de=Integer.parseInt(desc);
  if(canti<=-1)
  {
  JOptionPane.showMessageDialog(null, "No se puede Resalizar la venta");
  }               
  else{
      
  
  if(de==0)
                 {
                 String can=cantidad.getText();
                 c=Integer.parseInt(can);
                  multi=c*precioV;
                 exis=canti-c;
                 
                 String tota=Total.getText();
                 float to=Float.parseFloat(tota);
                 suma=multi+to;
                 Total.setText(""+suma);
                
                 fila[0]=code;
                 fila[1]=producto;
                 fila[2]=c;
                 fila[3]=multi;
                 
     modelo.addRow(fila);
     Inventario.setModel(modelo);
                 }
                 else
                 {
                 int decu=Integer.parseInt(desc);
                 String can=cantidad.getText();
                  c=Integer.parseInt(can);
       
                 float descu=precioV*decu/100;
                 float tot=precioV-descu;
                  multi=c*tot;
                  exis=canti-c;
                
                 String tota=Total.getText();
                 float to=Float.parseFloat(tota);
                 suma=multi+to;
                 Total.setText(""+suma);
                 
                 fila[0]=code;
                 fila[1]=producto;
                 fila[2]=c;
                 fila[3]=multi;
                 
     modelo.addRow(fila);
     Inventario.setModel(modelo);
                 }
  }               
                 pagar.setEnabled(true);
               Tab.requestFocus();
                    }
                }
                     catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "no hay conexion");
            }
if(canti<=10)
{
                JOptionPane.showMessageDialog(null, "Solo le Queda poco"+canti+"Producto");
}

if(canti==0)
{
                JOptionPane.showMessageDialog(null, "no hay Producto");
}
if(canti<=-1)
{
int ca=0;
try
{
              st.executeUpdate("UPDATE producto SET cantidad='"+ca+"' WHERE codigo='"+codigo.getText()+"'&& categoria='"+variable+"'");

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
            }
}
else
{
try
{
              st.executeUpdate("UPDATE producto SET cantidad='"+exis+"' WHERE codigo='"+codigo.getText()+"'");

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
            }


 try
            {
                st.executeUpdate("INSERT INTO salida VALUES(id, '"+code+"','"+producto+"','"+c+"','"+multi+"','"+jLabel11.getText()+"','"+variable+"')");
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
            }



}
  codigo.setText("");
  cantidad.setText("");
}

    }//GEN-LAST:event_cantidadKeyPressed

    private void descuentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_descuentoActionPerformed

    }//GEN-LAST:event_descuentoActionPerformed

    private void pagarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pagarMouseClicked
String paga=JOptionPane.showInputDialog("Total a Pagar");
float pago=Float.parseFloat(paga);
float vuelto=pago-suma;
pagos.setText(pago+"");
cambio.setText(""+vuelto);

 
 try
            {
                st.executeUpdate("INSERT INTO total VALUES(id,'"+Nit.getText()+"','"+cliente.getText()+"','"+jLabel11.getText()+"','"+suma+"','"+pago+"','"+vuelto+"','"+codig+"')");
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "No se pudo establecer Conexión");
            }
nueva.setEnabled(true);
    }//GEN-LAST:event_pagarMouseClicked

    private void clienteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_clienteKeyPressed
if(evt.getKeyCode()==evt.VK_ENTER)
{
Tab.requestFocus();
}
    }//GEN-LAST:event_clienteKeyPressed

    private void codigoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codigoKeyPressed
if(evt.getKeyCode()==evt.VK_ENTER)
{
cantidad.requestFocus();
}
    }//GEN-LAST:event_codigoKeyPressed

    private void nuevaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nuevaMouseClicked
  
             Total.setText("0");
             pagos.setText("0");
             cambio.setText("0");
              Nit.setText("");
              bienvenida.setText("Bienvenido a la Venta");
             cliente.setText("");
              codigo.setText("");
              cantidad.setText("");
              Password.requestFocus();
              Nit.setEditable(false);
           cliente.setEditable(false);
               codigo.setEditable(false);
               cantidad.setEditable(false);
               ingresar.setEnabled(false);
               actualizar.setEnabled(false);
               pagar.setEnabled(false);
               Password.setText("");
               Password.setEditable(true);
        int eliminar=Inventario.getRowCount();
    
       try{
for(int i=0;i<=eliminar;i++){
    
           modelo.removeRow(Inventario.getRowCount()-1);
}
    }
    catch(Exception e)
            {
            JOptionPane.showInternalMessageDialog(null,"" );
           
            }
                     
    }//GEN-LAST:event_nuevaMouseClicked

    private void TabKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TabKeyPressed
if(evt.getKeyCode()==evt.VK_ENTER)
{
descuento.requestFocus();
}        // TODO add your handling code here:
    }//GEN-LAST:event_TabKeyPressed

    private void descuentoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_descuentoMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_descuentoMouseClicked

    private void descuentoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_descuentoKeyPressed
if(evt.getKeyCode()==evt.VK_ENTER)
{
codigo.requestFocus();
}     }//GEN-LAST:event_descuentoKeyPressed

    private void PasswordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PasswordKeyPressed
if(evt.getKeyCode()==evt.VK_ENTER){
try
                {
                    ResultSet rt=st.executeQuery("SELECT * FROM usuario WHERE contraseña='"+Password.getText()+"'");

                    while(rt.next())
                    {
                        
        String nombre=rt.getString("nombre");
         codig=rt.getString("contraseña");
         String u=rt.getString("usuario");
         if("Administrador".equals(u))
         {
        bienvenida.setText("Bienvenido a las Ventas Administrador: "+nombre);
        Nit.setEditable(true);
        Nit.requestFocus();
        Password.setEditable(false);            
         }
         if("Trabajador".equals(u))
         { 
        bienvenida.setText("Bienvenido a las Ventas Usuario: "+nombre);
        Nit.setEditable(true);
        Nit.requestFocus();
        Password.setEditable(false);             
         }
         }     
                }
        
                     catch(Exception e)
            {
               
            }

                        
        
                    
}
    }//GEN-LAST:event_PasswordKeyPressed

  
    public static void main(String args[]) {
    
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentasAlContado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentasAlContado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentasAlContado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentasAlContado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

    
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new VentasAlContado().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Inventario;
    private javax.swing.JTextField Nit;
    private javax.swing.JPasswordField Password;
    private javax.swing.JComboBox Tab;
    private javax.swing.JTextField Total;
    private javax.swing.JButton actualizar;
    private javax.swing.JLabel bienvenida;
    private javax.swing.JTextField cambio;
    private javax.swing.JTextField cantidad;
    private javax.swing.JTextField cliente;
    private javax.swing.JTextField codigo;
    private javax.swing.JComboBox descuento;
    private javax.swing.JButton ingresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton nueva;
    private javax.swing.JButton pagar;
    private javax.swing.JTextField pagos;
    // End of variables declaration//GEN-END:variables
}
