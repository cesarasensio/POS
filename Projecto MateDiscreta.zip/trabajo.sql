-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 19-06-2012 a las 14:54:53
-- Versión del servidor: 5.5.24-log
-- Versión de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `trabajo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `año`
--

CREATE TABLE IF NOT EXISTS `año` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `año` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `año`
--

INSERT INTO `año` (`id`, `año`) VALUES
(1, 2012);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nit` varchar(45) NOT NULL,
  `cliente` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`id`, `nit`, `cliente`) VALUES
(1, '1234', 'carlos sal');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientos`
--

CREATE TABLE IF NOT EXISTS `movimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(45) NOT NULL,
  `producto` varchar(45) NOT NULL,
  `movimiento` int(11) NOT NULL,
  `total movimiento` varchar(45) NOT NULL,
  `fecha` date NOT NULL,
  `precioCompra` float NOT NULL,
  `totalCompra` float NOT NULL,
  `precioVenta` float NOT NULL,
  `totalVenta` float NOT NULL,
  `causa` varchar(45) NOT NULL,
  `tipo movimiento` varchar(45) NOT NULL,
  `sucursal` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Volcado de datos para la tabla `movimientos`
--

INSERT INTO `movimientos` (`id`, `codigo`, `producto`, `movimiento`, `total movimiento`, `fecha`, `precioCompra`, `totalCompra`, `precioVenta`, `totalVenta`, `causa`, `tipo movimiento`, `sucursal`) VALUES
(1, '123-wq', 'tennis Nike', 2, '198', '2012-06-18', 200, 400, 400, 800, 'mal manejo', 'Devolucion por Ventas', ''),
(2, '123-wq', 'tennis Nike', 4, '200', '2012-06-18', 200, 800, 400, 1600, 'mal manejo', 'Devolucion por Ventas', ''),
(3, '123-wq', 'tennis Nike', 3, '197', '2012-06-18', 200, 600, 400, 1200, 'mal manejo', 'Devolucion por Compra', ''),
(4, '123-wq', 'tennis Nike', 3, '203', '2012-06-18', 200, 600, 400, 1200, 'Defecto de fabrica', 'Devolucion por Ventas', 'vacio'),
(5, '123-wq', 'tennis Nike', 2, '201', '2012-06-19', 200, 40200, 400, 80400, 'vacio', 'Exportacion producto', 'Mazatenango'),
(6, '123-wq', 'tennis Nike', 3, '204', '2012-06-19', 200, 40800, 400, 81600, 'vacio', 'Importar', 'Mazate'),
(7, '123-wq', 'tennis Nike', 4, '205', '2012-06-19', 200, 41000, 400, 82000, 'vacio', 'Importar', 'Mazate'),
(8, '123-wq', 'tennis Nike', 4, '205', '2012-06-19', 200, 41000, 400, 82000, 'vacio', 'Importar', 'Mazate');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE IF NOT EXISTS `producto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(45) NOT NULL,
  `producto` varchar(45) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precioCosto` varchar(45) NOT NULL,
  `precioVenta` varchar(45) NOT NULL,
  `categoria` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id`, `codigo`, `producto`, `cantidad`, `precioCosto`, `precioVenta`, `categoria`) VALUES
(1, '123-wq', 'tennis Nike', 205, '200', '400', 'calzado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `salida`
--

CREATE TABLE IF NOT EXISTS `salida` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(45) NOT NULL,
  `producto` varchar(45) NOT NULL,
  `cantidad` varchar(45) NOT NULL,
  `precio` varchar(45) NOT NULL,
  `fecha` date NOT NULL,
  `categoria` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `salida`
--

INSERT INTO `salida` (`id`, `codigo`, `producto`, `cantidad`, `precio`, `fecha`, `categoria`) VALUES
(1, 'null', 'null', '0', '0.0', '2012-06-18', 'calzado'),
(2, 'null', 'null', '0', '0.0', '2012-06-18', 'calzado'),
(3, '123-wq', 'tennis Nike', '2', '800.0', '2012-06-18', 'calzado'),
(4, '123-wq', 'tennis Nike', '2', '800.0', '2012-06-18', 'calzado'),
(5, '123-wq', 'tennis Nike', '2', '800.0', '2012-06-18', 'calzado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `total`
--

CREATE TABLE IF NOT EXISTS `total` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nit` varchar(45) NOT NULL,
  `cliente` varchar(45) NOT NULL,
  `fecha` date NOT NULL,
  `total` float NOT NULL,
  `pago` float NOT NULL,
  `cambio` float NOT NULL,
  `codigousuario` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `total`
--

INSERT INTO `total` (`id`, `nit`, `cliente`, `fecha`, `total`, `pago`, `cambio`, `codigousuario`) VALUES
(1, '1234', 'carlos sal', '2012-06-18', 800, 800, 0, '123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contraseña` varchar(45) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `usuario` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `contraseña`, `nombre`, `usuario`) VALUES
(2, 'cesar', 'Eduardo', 'Administrador'),
(4, '123', 'Otto', 'Trabajador');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
